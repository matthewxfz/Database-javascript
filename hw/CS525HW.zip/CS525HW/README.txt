#Members:
1. Fangzhou Xiong	A20376382    <fxiong4@hawk.iit.edu> 33.33%
2. Zhiquan  Li		A20381063	 <zli175@hawk.iit.edu>  33.33%
3. Guangda  Li		A20360157    <gli32@hawk.iit.edu>   33.33%

#Instruction of running program:
1. unpack the zip file to local
2. open eclipse or other IDE of Java
3. create a project and put files in the project file
4. modify the input table router and output table router according to your computer condition
5. run the program.

#API:
1. cartesianProduct: complete cartesian product functionality
2. interSect: 		 complete intersection functionality
3. naturalJoin:		 complete natural join functionality with two tables
4. countAndAvg:		 complete count and average computation functionality and input negative number in groupby attributes
					 to get total number of tuples, and input positive number in grouby attributes and target
					 to get corresponding number of tuples and average.
5. distinctValue:	 complete distinct functionality

ps.If you want to change tables for test,please make sure each column is divided by comma