import java.io.File;
import java.io.IOException;

public class test {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		QueryMethod qm = new QueryMethod();
		String url1 = "D:\\js\\cs525\\table1.csv";
		String url2 = "D:\\js\\cs525\\table2.csv";
		String url3 = "D:\\js\\cs525\\interSect.csv";
		String url4 = "D:\\js\\cs525\\cartesianproduct.csv";
		String url5 = "D:\\js\\cs525\\naturalJoin.csv";
		String url6 = "D:\\js\\cs525\\distinctValue.csv";
		String url7 = "D:\\js\\cs525\\countAndAvg.csv";
		String url8 = "D:\\js\\cs525\\tmp.csv";
		String url9 = "D:\\js\\cs525\\helper.csv";
		String url10 = "D:\\js\\cs525\\table3.csv";
		File file1 = new File(url1);
		File file2 = new File(url2);
		File file3 = new File(url10);
		File interSect = new File(url3);
		File cartesianproduct = new File(url4);
		File naturalJoin = new File(url5);
		File distinctValue = new File(url6);
		File countAndAvg = new File(url7);
		File tmp = new File(url8);
		File helper = new File(url9);
		qm.cartesianProduct(file1, file2,cartesianproduct);
		qm.interSect(file1, file3, interSect);
		qm.naturalJoin(file1, file2, naturalJoin);
		qm.distinctValue(file2, distinctValue);
		qm.countAndAvg(file1, countAndAvg,tmp,helper,2,3);
		

	}

}
