import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class QueryMethod {
	public void cartesianProduct(File file1,File file2,File fileOut) throws IOException{
		FileInputStream inputstream1 = null;
		FileInputStream inputstream2 = null;
		FileOutputStream outputstream = null;
		Scanner sc1 = null;
		Scanner sc2 = null;
		boolean isRowOneOut = true;
		boolean isRowOneIn = true;
		try {
			inputstream1 = new FileInputStream(file1);
			outputstream = new FileOutputStream(fileOut,true);
			sc1 = new Scanner(inputstream1,"UTF-8");
			while(sc1.hasNextLine()){
				String line1 = sc1.nextLine();
				inputstream2 = new FileInputStream(file2);
				sc2 = new Scanner(inputstream2,"UTF-8");
				while(sc2.hasNextLine()){
					String line2 = sc2.nextLine();
					if(isRowOneOut){
						String[] array1 = line1.split(",");
						String[] array2 = line2.split(",");
						StringBuffer sb1 = new StringBuffer();
						StringBuffer sb2 = new StringBuffer();
						for(int i = 0;i < array1.length;i++){
							sb1.append(array1[i]+",");
							for(int j = 0;j < array2.length;j++){
								if(array1[i].equals(array2[j]))
									array2[j] = "R." + array2[j];
							}
							if(i < array2.length){
								sb2.append(array2[i] + ((i == array2.length - 1) ? "\n" : ","));
							}
						}
						line2 = sb1.toString() + sb2.toString();
						outputstream.write(line2.getBytes());
						isRowOneOut = false;
						break;
					}else if(isRowOneIn){
						isRowOneIn = false;
						continue;
					}else{
						line2 = line1 + "," + line2 + '\n';
						outputstream.write(line2.getBytes());
					}
				}
				isRowOneIn = true;
			}
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e.toString());
		}finally {
			outputstream.close();
		}
	}
	
	public void interSect(File file1,File file2,File fileOut) throws IOException{
		FileInputStream inputstream1 = null;
		FileInputStream inputstream2 = null;
		FileOutputStream outputstream = null;
		Scanner sc1 = null;
		Scanner sc2 = null;
		boolean isRowOneOut = true;
		boolean isRowOneIn = true;
		try {
			inputstream1 = new FileInputStream(file1);
			outputstream = new FileOutputStream(fileOut,true);
			sc1 = new Scanner(inputstream1,"UTF-8");
			while(sc1.hasNextLine()){
				String line1 = sc1.nextLine();
				if(isRowOneOut){
					isRowOneOut = false;
					line1 += "\n";
					outputstream.write(line1.getBytes());
					continue;
				}
				inputstream2 = new FileInputStream(file2);
				sc2 = new Scanner(inputstream2,"UTF-8");
				while(sc2.hasNextLine()){
					if(isRowOneIn){
						isRowOneIn = false;
						continue;
					}
					String line2 = sc2.nextLine();
					if(line1.equals(line2)){
						FileInputStream inputstream3 = new FileInputStream(fileOut);
						Scanner sc3 = new Scanner(inputstream3,"UTF-8");
						boolean flag = true;
						while(sc3.hasNextLine()){
							String line3 = sc3.nextLine();
							if(line1.equals(line3)){
								flag = false;
							}
						}
						if(flag){
							line1 += "\n";
							outputstream.write(line1.getBytes());
						}
					}
				}
				isRowOneIn = true;
			}
		} catch (Exception e) {
			System.out.println(e.toString());
			// TODO: handle exception
		}finally {
			outputstream.close();
		}
	}
	
	public void naturalJoin(File file1,File file2,File fileOut) throws IOException{
		FileInputStream inputstream1 = null;
		FileInputStream inputstream2 = null;
		FileOutputStream outputstream = null;
		Scanner sc1 = null;
		Scanner sc2 = null;
		boolean isRowOneOut = true;
		boolean isRowOneIn = true;
		try {
			inputstream1 = new FileInputStream(file1);
			outputstream = new FileOutputStream(fileOut);
			sc1 = new Scanner(inputstream1,"UTF-8");
			String scolumn1 = "",
				   scolumn2 = "";
			while(sc1.hasNextLine()){
				inputstream2 = new FileInputStream(file2);
				String line1 = sc1.nextLine();
				sc2 = new Scanner(inputstream2,"UTF-8");
				while(sc2.hasNextLine()){
					String line2 = sc2.nextLine();
					String[] array1 = line1.split(",");
					String[] array2 = line2.split(",");
					if(isRowOneOut){
						StringBuffer sb = new StringBuffer();
						//searching the same column and mark it
						for(int i = 0;i <  array1.length;i++)
							for(int j = 0;j < array2.length;j++){
								if(array1[i].equals(array2[j])){
									scolumn1 += i;
									scolumn2 += j;
									break;
								}
							}
						//reconstruction of attributes for new relation
						int count = 0;
						for(int i = 0;i < array2.length;i++){
							if(scolumn2.contains(i+""))
								continue;
							sb.append(array2[i]);
							if(count < array2.length - scolumn2.length() - 1)
								sb.append(",");
							count++;
						}
						outputstream.write((line1 + "," + sb.toString() + "\n").getBytes());
						isRowOneOut = false;
						break;
					}
					if(isRowOneIn) {
						isRowOneIn = false;
						continue;
					}
					boolean isEqual = true;
					for(int i = 0;i < scolumn1.length();i++){
						if(!array1[Integer.valueOf(scolumn1.charAt(i)+"")].equals(array2[Integer.valueOf(scolumn2.charAt(i)+"")])
							){
							isEqual = false;
							break;
						}
					}
					if(isEqual){
						int count = 0;
						StringBuffer sb = new StringBuffer();
						for(int i = 0;i < array2.length;i++){
							if(scolumn2.contains(i+""))
								continue;
							sb.append(array2[i]);
							count++;
							if(count < array2.length - scolumn2.length())
								sb.append(",");
						}
						outputstream.write((line1 + "," + sb.toString() + "\n").getBytes());
					}
				}
				isRowOneIn = true;
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}finally {
			outputstream.close();
		}
	}
	
	public void countAndAvg(File file1,File fileOut,File tmp,File helper,int target,int attrGroupBy) throws IOException{
		String title = "";
		double[] avg;
		FileInputStream inputstream = null;
		FileOutputStream outputStream = null;
		Scanner sc = null;
		boolean isRowOneOut = true;
		boolean isRowOneIn = true;
		inputstream = new FileInputStream(file1);
		outputStream = new FileOutputStream(fileOut);
		try {
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		if(attrGroupBy < 0){
			sc = new Scanner(inputstream,"UTF-8");
			int count = 0;
			while(sc.hasNextLine()){
				String line = sc.nextLine();
				if(isRowOneOut){
					String str = "Count(*)\n";
					outputStream.write(str.getBytes());
					isRowOneOut = false;
					continue;
				}
				count++;
			}
			String str = count + "\n";
			outputStream.write(str.getBytes());
		}else{
			sc = new Scanner(inputstream,"UTF-8");
			FileOutputStream ops = new FileOutputStream(helper);
			FileOutputStream ops1 = new FileOutputStream(tmp);
			while(sc.hasNextLine()){
				String copy = sc.nextLine() + "\n";
				ops.write(copy.getBytes());
			}
			ops.close();
			sc.close();
			sc = null;
			sc = new Scanner(new FileInputStream(file1));
			Scanner sc2 = new Scanner(new FileInputStream(helper));
			while(sc.hasNext()){
				int count = 0;
				int avgv = 0;
				String line1 = sc.nextLine();
				String[] arrayline1 = line1.split(",");
				if(isRowOneOut){
					ops1.write(("Count(*),Avg(" + arrayline1[target] + ")," + arrayline1[attrGroupBy] + "\n").getBytes());
					isRowOneOut = false;
					continue;
				}
				while(sc2.hasNextLine()){
					String line2 = sc2.nextLine();
					if(isRowOneIn){
						isRowOneIn = false;
						continue;
					}
					
					String[] arrayline2 = line2.split(",");
					if(arrayline1[attrGroupBy].equals(arrayline2[attrGroupBy])){
						avgv += Integer.valueOf(arrayline2[target]);
						count++;
					}
				}
				avgv /= count;
				isRowOneIn = true;
				sc2.close();
				sc2 = null;
				sc2 = new Scanner(new FileInputStream(helper));
				ops1.write((count + "," + avgv + "," + arrayline1[attrGroupBy] + "\n").getBytes());
				
			}
			distinctValue(tmp,fileOut);
			ops1.close();
			sc2.close();
			sc.close();
		}
	}
	
	public void distinctValue(File file1,File fileOut) throws IOException {
		FileInputStream inputstream1 = null;
		FileInputStream inputstream2 = null;
		FileOutputStream outputstream = null;
		Scanner sc1 = null;
		Scanner sc2 = null;
		boolean isRowOneOut = true;
		boolean isRowOneIn = true;
		try {
			inputstream1 = new FileInputStream(file1);
			outputstream = new FileOutputStream(fileOut,true);
			sc1 = new Scanner(inputstream1,"UTF-8");
			while(sc1.hasNextLine()){
				String line1 = sc1.nextLine();
				if(isRowOneOut){
					outputstream.write((line1 + "\n").getBytes());
					isRowOneOut = false;
					continue;
				}
				boolean flag = true;
				inputstream2 = new FileInputStream(fileOut);
				sc2 = new Scanner(inputstream2,"UTF-8");
				while(sc2.hasNextLine()){
					if(isRowOneIn){
						isRowOneIn = false;
						continue;
					}
					String line2 = sc2.nextLine();
					if((line1).equals(line2)){
						flag = false;
						break;
					}
				}
				isRowOneIn = true;
				if(flag)
					outputstream.write((line1 + "\n").getBytes());
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}finally {
			outputstream.close();
		}
	}
}
